import streamlit as st
from storage.user_storage import get_all_users
from storage.project_storage import get_all_projects
from storage.user_project_storage import (
    associate_users_projects,
    remove_user_project_association,
    get_all_user_projects
)


@st.dialog("Associate Users to Projects", width="medium")
def render_user_project_modal():

    users = get_all_users()
    projects = get_all_projects()
    associations = get_all_user_projects()

    if not users or not projects:
        st.warning("No users or projects available.")
        return

    st.markdown("### Associate Users")

    user_options = {
        u["email_hash"]: f"{u['full_name']} ({u['email']})"
        for u in users
    }

    project_options = {
        p["project_id"]: p["name"]
        for p in projects
        if str(p.get("is_active", True)).lower() == "true"
    }

    selected_users = st.multiselect(
        "Users",
        options=list(user_options.keys()),
        format_func=lambda x: user_options[x]
    )

    selected_projects = st.multiselect(
        "Projects",
        options=list(project_options.keys()),
        format_func=lambda x: project_options[x]
    )

    if st.button("Associate", use_container_width=True):

        if not selected_users or not selected_projects:
            st.warning("Select at least one user and one project.")
            return

        associate_users_projects(
            selected_users,
            selected_projects,
            st.session_state.user_id
        )

        st.success("Users successfully associated.")
        st.rerun()

    st.divider()

    # -------- REMOVE LINK --------
    st.markdown("### Remove Link")

    if not associations:
        st.info("No existing associations.")
        return

    assoc_map = [
        (a["user_id"], a["project_id"])
        for a in associations
    ]

    assoc_display = {
        f"{u} | {p}": (u, p)
        for u, p in assoc_map
    }

    selected_assoc = st.selectbox(
        "Existing Links",
        options=list(assoc_display.keys())
    )

    has_links = bool(assoc_display)

    if st.button(
        "🗑 Remove Association",
        use_container_width=True,
        disabled=not has_links
    ):

        user_id, project_id = assoc_display[selected_assoc]

        remove_user_project_association(
            user_id,
            project_id
        )

        st.success("Association removed successfully.")
        st.rerun()
