import streamlit as st
from datetime import datetime
from storage.google_sheets import get_sheet


# -------------------------
# GET PROJECTS FOR USER
# -------------------------
@st.cache_data(ttl=30, show_spinner=False)
def get_projects_for_user(user_id: str):

    sheet = get_sheet("usersprojects")
    rows = sheet.get_all_records()

    return [
        r["project_id"]
        for r in rows
        if r.get("user_id") == user_id
    ]


# -------------------------
# ASSOCIATE USERS TO PROJECTS
# -------------------------
def associate_users_projects(user_ids: list, project_ids: list, created_by: str):

    sheet = get_sheet("usersprojects")
    rows = sheet.get_all_records()

    existing = {(r["user_id"], r["project_id"]) for r in rows}
    now = datetime.utcnow().isoformat()

    rows_to_add = []

    for user_id in user_ids:
        for project_id in project_ids:
            if (user_id, project_id) not in existing:
                rows_to_add.append([
                    user_id,
                    project_id,
                    now,
                    created_by
                ])

    if rows_to_add:
        sheet.append_rows(rows_to_add)


# -------------------------
# REMOVE ASSOCIATION OF USERS TO PROJECTS
# -------------------------
def remove_user_project_association(user_id: str, project_id: str):

    sheet = get_sheet("usersprojects")
    rows = sheet.get_all_records()

    for idx, row in enumerate(rows, start=2):
        if row["user_id"] == user_id and row["project_id"] == project_id:
            sheet.delete_rows(idx)
            break